package com.btc.vpn

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LoginActivity : AppCompatActivity() {

    private lateinit var usernameInput: TextInputEditText
    private lateinit var passwordInput: TextInputEditText
    private lateinit var loginButton: Button
    private lateinit var loadingProgress: ProgressBar
    private lateinit var errorText: TextView
    private lateinit var authManager: AuthManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        authManager = AuthManager(this)

        // إذا كان مسجل دخول بالفعل → انتقل للشاشة الرئيسية
        if (authManager.isLoggedIn()) {
            goToMain()
            return
        }

        usernameInput   = findViewById(R.id.usernameInput)
        passwordInput   = findViewById(R.id.passwordInput)
        loginButton     = findViewById(R.id.loginButton)
        loadingProgress = findViewById(R.id.loadingProgress)
        errorText       = findViewById(R.id.errorText)

        loginButton.setOnClickListener { performLogin() }

        // دعم مفتاح Enter من لوحة المفاتيح
        passwordInput.setOnEditorActionListener { _, _, _ ->
            performLogin()
            true
        }
    }

    private fun performLogin() {
        val username = usernameInput.text.toString().trim()
        val password = passwordInput.text.toString()

        if (username.isEmpty() || password.isEmpty()) {
            showError("يرجى إدخال اسم المستخدم وكلمة المرور")
            return
        }

        setLoading(true)
        hideError()

        // بيانات الجهاز
        val deviceId    = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
        val deviceModel = "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}"
        val deviceOs    = "Android ${android.os.Build.VERSION.RELEASE}"

        CoroutineScope(Dispatchers.Main).launch {
            try {
                val response = withContext(Dispatchers.IO) {
                    ApiClient.instance.login(
                        LoginRequest(
                            username     = username,
                            password     = password,
                            device_id    = deviceId,
                            device_model = deviceModel,
                            device_os    = deviceOs
                        )
                    )
                }

                setLoading(false)

                when {
                    response.banned -> {
                        showError("⛔ ${response.message}")
                    }
                    response.success && response.data != null -> {
                        authManager.saveToken(response.data.token)
                        authManager.saveUsername(username)
                        authManager.saveDeviceId(deviceId)
                        Toast.makeText(this@LoginActivity, "مرحباً ${response.data.user.username}!", Toast.LENGTH_SHORT).show()
                        goToMain()
                    }
                    else -> showError(response.message)
                }

            } catch (e: Exception) {
                setLoading(false)
                showError("خطأ في الاتصال بالخادم\n${e.message}")
            }
        }
    }

    private fun goToMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun setLoading(loading: Boolean) {
        loadingProgress.visibility = if (loading) View.VISIBLE else View.GONE
        loginButton.isEnabled = !loading
        loginButton.text = if (loading) "جاري الاتصال..." else "تسجيل الدخول"
    }

    private fun showError(message: String) {
        errorText.text = message
        errorText.visibility = View.VISIBLE
    }

    private fun hideError() {
        errorText.visibility = View.GONE
    }
}
