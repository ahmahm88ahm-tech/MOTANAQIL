package com.btc.vpn

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var companySpinner: Spinner
    private lateinit var serverSpinner: Spinner
    private lateinit var connectButton: Button
    private lateinit var logoutButton: Button
    private lateinit var statusText: TextView
    private lateinit var statusDot: TextView
    private lateinit var serverInfoText: TextView
    private lateinit var loadingProgress: ProgressBar
    private lateinit var authManager: AuthManager

    private var companies      = listOf<Company>()
    private var allServers     = listOf<Server>()
    private var filteredServers = listOf<Server>()
    private var selectedServer: Server? = null
    private var isConnected = false

    // روابط التمويه: key = company_id كـ String (كما يرسلها الخادم)
    private var spoofUrlsMap = mapOf<String, List<SpoofUrl>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        authManager = AuthManager(this)

        companySpinner  = findViewById(R.id.companySpinner)
        serverSpinner   = findViewById(R.id.serverSpinner)
        connectButton   = findViewById(R.id.connectButton)
        logoutButton    = findViewById(R.id.logoutButton)
        statusText      = findViewById(R.id.statusText)
        statusDot       = findViewById(R.id.statusDot)
        serverInfoText  = findViewById(R.id.serverInfoText)
        loadingProgress = findViewById(R.id.loadingProgress)

        loadServers()

        connectButton.setOnClickListener {
            if (isConnected) disconnectVpn() else connectToVpn()
        }

        logoutButton.setOnClickListener { performLogout() }
    }

    // ── جلب السيرفرات وروابط التمويه من الخادم ───────────────
    private fun loadServers() {
        loadingProgress.visibility = View.VISIBLE
        connectButton.isEnabled = false

        CoroutineScope(Dispatchers.Main).launch {
            try {
                val token = authManager.getToken() ?: return@launch
                val response = withContext(Dispatchers.IO) {
                    ApiClient.instance.getServers("Bearer $token")
                }

                loadingProgress.visibility = View.GONE
                connectButton.isEnabled = true

                if (response.success) {
                    companies      = response.companies
                    allServers     = response.servers
                    spoofUrlsMap   = response.spoof_urls ?: emptyMap()
                    setupCompanySpinner()
                } else {
                    Toast.makeText(this@MainActivity, "فشل جلب السيرفرات", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                loadingProgress.visibility = View.GONE
                Toast.makeText(this@MainActivity, "خطأ في الاتصال: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    // ── إعداد قائمة الشركات ───────────────────────────────────
    private fun setupCompanySpinner() {
        val names = companies.map { it.name_ar }
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, names)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        companySpinner.adapter = adapter

        companySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, pos: Int, id: Long) {
                filterServers(companies[pos].id)
            }
            override fun onNothingSelected(parent: AdapterView<*>) {}
        }
    }

    // ── تصفية السيرفرات حسب الشركة ───────────────────────────
    private fun filterServers(companyId: Int) {
        filteredServers = allServers.filter { it.company_id == companyId }
        val names = filteredServers.map { it.display_name }
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, names)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        serverSpinner.adapter = adapter

        serverSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, pos: Int, id: Long) {
                selectedServer = if (filteredServers.isNotEmpty()) filteredServers[pos] else null
            }
            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        if (filteredServers.isNotEmpty()) selectedServer = filteredServers[0]
    }

    // ── اختيار رابط تمويه عشوائي للشركة ─────────────────────
    private fun pickSpoofUrl(companyId: Int): String {
        val urls = spoofUrlsMap[companyId.toString()]
        return urls?.randomOrNull()?.url ?: selectedServer?.sni_hostname ?: ""
    }

    // ── الاتصال بالـ VPN ───────────────────────────────────────
    private fun connectToVpn() {
        val server = selectedServer ?: run {
            Toast.makeText(this, "يرجى اختيار سيرفر", Toast.LENGTH_SHORT).show()
            return
        }

        val spoofUrl = pickSpoofUrl(server.company_id)
        setConnecting()

        // محاكاة الاتصال (يُستبدل لاحقاً بـ VpnService الحقيقي)
        android.os.Handler(mainLooper).postDelayed({
            setConnected(server, spoofUrl)
        }, 2000)
    }

    // ── قطع الاتصال ───────────────────────────────────────────
    private fun disconnectVpn() {
        isConnected = false
        statusText.text = "غير متصل"
        statusText.setTextColor(getColor(android.R.color.holo_red_dark))
        statusDot.setBackgroundColor(getColor(android.R.color.holo_red_dark))
        serverInfoText.text = ""
        connectButton.text = "اتصال"
        connectButton.backgroundTintList = getColorStateList(android.R.color.holo_green_dark)
        Toast.makeText(this, "تم قطع الاتصال", Toast.LENGTH_SHORT).show()
    }

    // ── حالات الزر ────────────────────────────────────────────
    private fun setConnecting() {
        connectButton.text = "جاري الاتصال..."
        connectButton.isEnabled = false
        loadingProgress.visibility = View.VISIBLE
    }

    private fun setConnected(server: Server, spoofUrl: String) {
        isConnected = true
        loadingProgress.visibility = View.GONE
        connectButton.isEnabled = true
        connectButton.text = "قطع الاتصال"
        connectButton.backgroundTintList = getColorStateList(android.R.color.holo_red_dark)
        statusText.text = "متصل ✓"
        statusText.setTextColor(getColor(android.R.color.holo_green_dark))
        statusDot.setBackgroundColor(getColor(android.R.color.holo_green_dark))
        serverInfoText.text = "${server.display_name}  •  ${server.host}:${server.port}  •  ${server.protocol}\nSNI: $spoofUrl"
        Toast.makeText(this, "✅ تم الاتصال بـ ${server.display_name}", Toast.LENGTH_LONG).show()
    }

    // ── تسجيل الخروج ──────────────────────────────────────────
    private fun performLogout() {
        CoroutineScope(Dispatchers.Main).launch {
            try {
                val token = authManager.getToken()
                if (token != null) {
                    withContext(Dispatchers.IO) {
                        ApiClient.instance.logout("Bearer $token")
                    }
                }
            } catch (_: Exception) {}

            authManager.logout()
            startActivity(Intent(this@MainActivity, LoginActivity::class.java))
            finish()
        }
    }
}
