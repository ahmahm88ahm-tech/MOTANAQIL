package com.btc.vpn.models

// ملف مرجعي — النماذج الرئيسية موجودة في ApiClient.kt
// هذا الملف للاستخدام المستقبلي فقط
typealias ServerModel  = com.btc.vpn.Server
typealias CompanyModel = com.btc.vpn.Company
typealias UserModel    = com.btc.vpn.UserData
