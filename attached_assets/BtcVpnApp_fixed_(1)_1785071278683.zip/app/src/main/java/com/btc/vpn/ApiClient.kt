package com.btc.vpn

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*
import java.util.concurrent.TimeUnit

// ─── واجهة API ────────────────────────────────────────────────
interface ApiService {

    @POST("api/auth/login")
    suspend fun login(@Body request: LoginRequest): LoginResponse

    @POST("api/auth/logout")
    suspend fun logout(@Header("Authorization") token: String): BaseResponse

    @GET("api/servers")
    suspend fun getServers(@Header("Authorization") token: String): ServersResponse

    @POST("api/device/check")
    suspend fun checkDevice(@Body request: DeviceCheckRequest): DeviceCheckResponse

    @POST("api/detect-company")
    suspend fun detectCompany(@Body request: DetectCompanyRequest): DetectCompanyResponse

    // ── Spoof URLs ────────────────────────────────────────────
    @GET("api/spoof-urls/company/{companyId}")
    suspend fun getSpoofUrls(
        @Header("Authorization") token: String,
        @Path("companyId") companyId: Int
    ): SpoofUrlsResponse
}

// ─── النماذج (Models) ─────────────────────────────────────────
data class LoginRequest(
    val username: String,
    val password: String,
    val device_id: String,
    val device_model: String,
    val device_os: String
)

data class LoginResponse(
    val success: Boolean,
    val message: String,
    val data: LoginData?,
    val banned: Boolean = false
)

data class LoginData(
    val token: String,
    val user: UserData
)

data class UserData(
    val id: Int,
    val username: String,
    val full_name: String?,
    val data_limit_mb: Long,
    val expiry_date: String?
)

data class ServersResponse(
    val success: Boolean,
    val companies: List<Company>,
    val servers: List<Server>,
    val spoof_urls: Map<String, List<SpoofUrl>>?,   // مجمّعة حسب company_id كـ String
    val user: UserData?
)

data class Company(
    val id: Int,
    val name: String,
    val name_ar: String,
    val logo_url: String?
)

data class Server(
    val id: Int,
    val company_id: Int,
    val server_number: Int,
    val display_name: String,
    val host: String,
    val port: Int,
    val protocol: String,
    val server_type: String,
    val sni_hostname: String,
    val payload: String,
    val company_name: String?
)

data class SpoofUrl(
    val url: String,
    val description: String?
)

data class SpoofUrlsResponse(
    val success: Boolean,
    val urls: List<SpoofUrl>
)

data class DeviceCheckRequest(
    val username: String,
    val device_id: String,
    val device_model: String,
    val device_os: String
)

data class DeviceCheckResponse(
    val success: Boolean,
    val message: String,
    val banned: Boolean = false,
    val data: DeviceCheckData?
)

data class DeviceCheckData(
    val user_id: Int,
    val username: String,
    val expiry_date: String?
)

data class DetectCompanyRequest(val phone_number: String)

data class DetectCompanyResponse(
    val success: Boolean,
    val message: String,
    val company: Company?
)

data class BaseResponse(
    val success: Boolean,
    val message: String
)

// ─── ApiClient (Singleton) ────────────────────────────────────
object ApiClient {
    const val BASE_URL = "https://3fd65d93-c8f7-48a6-b46c-7421f08472d4-00-1lkef9lpasezt.spock.replit.dev/"

    val instance: ApiService by lazy {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }

        val client = OkHttpClient.Builder()
            .addInterceptor(logging)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()

        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }
}
